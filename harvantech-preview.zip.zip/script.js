// Mobile Navigation
const navMenu = document.getElementById('nav-menu');
const navToggle = document.getElementById('nav-toggle');
const navLinks = document.querySelectorAll('.nav__link');

// Show/hide mobile menu
if (navToggle) {
    navToggle.addEventListener('click', () => {
        navMenu.classList.toggle('show-menu');
    });
}

// Close mobile menu when clicking nav links
navLinks.forEach(n => n.addEventListener('click', () => {
    navMenu.classList.remove('show-menu');
}));

// Header scroll effect
function scrollHeader() {
    const header = document.getElementById('header');
    if (this.scrollY >= 50) {
        header.classList.add('scroll-header');
    } else {
        header.classList.remove('scroll-header');
    }
}
window.addEventListener('scroll', scrollHeader);

// Active link highlighting
const sections = document.querySelectorAll('section[id]');

function scrollActive() {
    const scrollY = window.pageYOffset;

    sections.forEach(current => {
        const sectionHeight = current.offsetHeight;
        const sectionTop = current.offsetTop - 50;
        const sectionId = current.getAttribute('id');

        if (scrollY > sectionTop && scrollY <= sectionTop + sectionHeight) {
            document.querySelector('.nav__menu a[href*=' + sectionId + ']').classList.add('active-link');
        } else {
            document.querySelector('.nav__menu a[href*=' + sectionId + ']').classList.remove('active-link');
        }
    });
}
window.addEventListener('scroll', scrollActive);

// Show scroll up button
function scrollUp() {
    const scrollUp = document.getElementById('scroll-up');
    if (this.scrollY >= 560) {
        scrollUp.classList.add('show-scroll');
    } else {
        scrollUp.classList.remove('show-scroll');
    }
}
window.addEventListener('scroll', scrollUp);

// Product tabs functionality
const tabButtons = document.querySelectorAll('.tab__button');
const tabContents = document.querySelectorAll('.tab__content');

tabButtons.forEach(button => {
    button.addEventListener('click', () => {
        const target = button.getAttribute('data-tab');
        
        // Remove active class from all buttons and contents
        tabButtons.forEach(btn => btn.classList.remove('active'));
        tabContents.forEach(content => content.classList.remove('active'));
        
        // Add active class to clicked button and corresponding content
        button.classList.add('active');
        document.getElementById(target).classList.add('active');
    });
});

// Contact form handling
const contactForm = document.querySelector('.contact__form');

if (contactForm) {
    contactForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        // Get form data
        const formData = new FormData(this);
        const name = this.querySelector('input[type="text"]').value;
        const company = this.querySelectorAll('input[type="text"]')[1].value;
        const phone = this.querySelector('input[type="tel"]').value;
        const email = this.querySelector('input[type="email"]').value;
        const requirements = this.querySelector('textarea').value;
        
        // Create WhatsApp message
        const message = `Hi HarvanTech Team!
        
Name: ${name}
Company: ${company || 'Not specified'}
Phone: ${phone}
Email: ${email || 'Not specified'}
Requirements: ${requirements || 'General inquiry'}

I'm interested in your air compressor solutions. Please contact me.`;
        
        // Open WhatsApp with pre-filled message
        const whatsappUrl = `https://wa.me/919211567526?text=${encodeURIComponent(message)}`;
        window.open(whatsappUrl, '_blank');
        
        // Show success message
        alert('Thank you for your inquiry! You will be redirected to WhatsApp to complete your message.');
        
        // Reset form
        this.reset();
    });
}

// Smooth scrolling for anchor links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    });
});

// Animate elements on scroll
const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px'
};

const observer = new IntersectionObserver(function(entries) {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.style.opacity = '1';
            entry.target.style.transform = 'translateY(0)';
        }
    });
}, observerOptions);

// Observe elements for animation
document.querySelectorAll('.product__card, .service__card, .feature').forEach(el => {
    el.style.opacity = '0';
    el.style.transform = 'translateY(30px)';
    el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
    observer.observe(el);
});

// Add loading state to buttons
document.querySelectorAll('.button').forEach(button => {
    if (button.getAttribute('href') && button.getAttribute('href').includes('wa.me')) {
        button.addEventListener('click', function() {
            const originalText = this.innerHTML;
            this.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Opening WhatsApp...';
            this.style.pointerEvents = 'none';
            
            setTimeout(() => {
                this.innerHTML = originalText;
                this.style.pointerEvents = 'auto';
            }, 2000);
        });
    }
    
    if (button.getAttribute('href') && button.getAttribute('href').includes('tel:')) {
        button.addEventListener('click', function() {
            const originalText = this.innerHTML;
            this.innerHTML = '<i class="fas fa-phone fa-pulse"></i> Calling...';
            this.style.pointerEvents = 'none';
            
            setTimeout(() => {
                this.innerHTML = originalText;
                this.style.pointerEvents = 'auto';
            }, 2000);
        });
    }
});

// Add Google Analytics (replace with your tracking ID)
window.dataLayer = window.dataLayer || [];
function gtag(){dataLayer.push(arguments);}
gtag('js', new Date());
gtag('config', 'GA_MEASUREMENT_ID'); // Replace with your actual GA4 measurement ID

// Track button clicks for analytics
document.querySelectorAll('.button').forEach(button => {
    button.addEventListener('click', function() {
        const buttonText = this.textContent.trim();
        const buttonHref = this.getAttribute('href');
        
        // Track in Google Analytics
        if (typeof gtag !== 'undefined') {
            gtag('event', 'click', {
                event_category: 'Button',
                event_label: buttonText,
                value: buttonHref
            });
        }
        
        // Track WhatsApp clicks
        if (buttonHref && buttonHref.includes('wa.me')) {
            if (typeof gtag !== 'undefined') {
                gtag('event', 'whatsapp_click', {
                    event_category: 'Contact',
                    event_label: 'WhatsApp Button Click'
                });
            }
        }
        
        // Track phone clicks
        if (buttonHref && buttonHref.includes('tel:')) {
            if (typeof gtag !== 'undefined') {
                gtag('event', 'phone_click', {
                    event_category: 'Contact',
                    event_label: 'Phone Button Click'
                });
            }
        }
    });
});

// Track form submissions
if (contactForm) {
    contactForm.addEventListener('submit', function() {
        if (typeof gtag !== 'undefined') {
            gtag('event', 'form_submit', {
                event_category: 'Contact',
                event_label: 'Contact Form Submission'
            });
        }
    });
}

// Performance optimization - Lazy loading for images
if ('IntersectionObserver' in window) {
    const imageObserver = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const img = entry.target;
                img.src = img.dataset.src;
                img.classList.remove('lazy');
                imageObserver.unobserve(img);
            }
        });
    });

    document.querySelectorAll('img[data-src]').forEach(img => {
        imageObserver.observe(img);
    });
}

// Add scroll progress indicator
function addScrollProgress() {
    const scrollProgress = document.createElement('div');
    scrollProgress.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        width: 0%;
        height: 3px;
        background: linear-gradient(90deg, #0066cc, #ff6b35);
        z-index: 9999;
        transition: width 0.1s ease;
    `;
    document.body.appendChild(scrollProgress);

    window.addEventListener('scroll', () => {
        const scrollTop = window.pageYOffset;
        const docHeight = document.body.offsetHeight;
        const winHeight = window.innerHeight;
        const scrollPercent = scrollTop / (docHeight - winHeight);
        const scrollPercentRounded = Math.round(scrollPercent * 100);
        scrollProgress.style.width = scrollPercentRounded + '%';
    });
}

// Initialize scroll progress on load
window.addEventListener('load', addScrollProgress);

// Add cookie consent (basic implementation)
function addCookieConsent() {
    const cookieConsent = document.createElement('div');
    cookieConsent.style.cssText = `
        position: fixed;
        bottom: 20px;
        left: 20px;
        right: 20px;
        background: rgba(0, 102, 204, 0.95);
        color: white;
        padding: 1rem;
        border-radius: 0.5rem;
        z-index: 10000;
        display: flex;
        justify-content: space-between;
        align-items: center;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
        font-size: 0.9rem;
    `;
    
    cookieConsent.innerHTML = `
        <span>We use cookies to enhance your experience. By continuing to visit this site you agree to our use of cookies.</span>
        <button onclick="this.parentElement.remove(); localStorage.setItem('cookieConsent', 'accepted')" 
                style="background: white; color: #0066cc; border: none; padding: 0.5rem 1rem; border-radius: 0.25rem; margin-left: 1rem; cursor: pointer; font-weight: 500;">
            Accept
        </button>
    `;
    
    if (!localStorage.getItem('cookieConsent')) {
        document.body.appendChild(cookieConsent);
    }
}

// Initialize cookie consent on load
window.addEventListener('load', addCookieConsent);

// Service Worker registration for PWA capabilities
if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
        navigator.serviceWorker.register('/sw.js')
            .then(registration => {
                console.log('SW registered: ', registration);
            })
            .catch(registrationError => {
                console.log('SW registration failed: ', registrationError);
            });
    });
}

console.log('HarvanTech website loaded successfully! 🚀');